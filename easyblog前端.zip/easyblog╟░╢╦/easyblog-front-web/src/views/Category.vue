<template>
  <Category :categoryType="0"></Category>
</template>

<script setup>
import Category from "@/views/components/Category.vue"

</script>

<style lang="scss" scoped>
</style>
