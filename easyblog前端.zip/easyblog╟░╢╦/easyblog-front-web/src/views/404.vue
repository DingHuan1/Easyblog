<template>
  <div>404</div>
</template>

<script setup>
</script>

<style lang="scss" scoped>
</style>
