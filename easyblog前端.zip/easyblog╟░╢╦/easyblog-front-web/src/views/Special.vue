<template>
  <Category :categoryType="1"></Category>
</template>

<script setup>
import Category from "@/views/components/Category.vue"

</script>

<style lang="scss" scoped>
</style>
